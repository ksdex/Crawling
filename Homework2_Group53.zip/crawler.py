import logging
import re
from urllib.parse import urlparse, urljoin, urldefrag, parse_qs
from bs4 import BeautifulSoup
import nltk
from collections import Counter
nltk.download('punkt')



logger = logging.getLogger(__name__)


class Crawler:
    """
    This class is responsible for scraping urls from the next available link in frontier and adding the scraped links to
    the frontier
    """

    def __init__(self, frontier, corpus):
        self.frontier = frontier
        self.corpus = corpus
        self.subdomain = dict()
        self.traps = set()
        self.valid_path = dict()

    def change_html_to_text(self, url_data):
        soup = BeautifulSoup(str(url_data['content']), features="html.parser")
        title = soup.find_all("title")
        page = soup.find_all("p")
        str_set = set()
        for tags in [title, page]:
            for tag in tags:
                lines = set(tag.text.replace("\r", "").replace("\t", "").replace("\\r", "").replace("\\t", "").split("\n"))
                str_set = str_set.union(lines)
        style = soup.find_all("style")
        if len(style) > 0:
            style_set = set()
            for tag in style:
                style_set = style_set.union(set(tag.text.replace("\r", "").replace("\t", "").split("\n")))
            str_set = str_set.difference(style_set)
        return str_set

    def start_crawling(self):
        """
        This method starts the crawling process which is scraping urls from the next available link in frontier and adding
        the scraped links to the frontier
        """
        #for analytics
        maxLinksURL = "" # prompt 2 to keep track of the url with most output
        maxLinksNum = 0 # prompt 2 to keep track of the number of output
        downloaded = set() #prompt 3 to store downloaded links
        longesturl = dict()
        words = Counter()
        stopwords = ["a","about","above","after","again","against","all","am","an","and","any","are","aren't","as","at","be","because","been","before","being","below","between","both","but","by","can't","cannot","could","couldn't","did","didn't","do","does","doesn't","doing","don't","down","during","each","few","for","from","further","had","hadn't","has","hasn't","have","haven't","having","he","he'd","he'll","he's","her","here","here's","hers","herself","him","himself","his","how","how's","i","i'd","i'll","i'm","i've","if","in","into","is","isn't","it","it's","its","itself","let's","me","more","most","mustn't","my","myself","no","nor","not","of","off","on","once","only","or","other","ought","our","ours	ourselves","out","over","own","same","shan't","she","she'd","she'll","she's","should","shouldn't","so","some","such","than","that","that's","the","their","theirs","them","themselves","then","there","there's","these","they","they'd","they'll","they're","they've","this","those","through","to","too","under","until","up","very","was","wasn't","we","we'd","we'll","we're","we've","were","weren't","what","what's","when","when's","where","where's","which","while","who","who's","whom","why","why's","with","won't","would","wouldn't","you","you'd","you'll","you're","you've","your","yours","yourself","yourselves"]
        
        while self.frontier.has_next_url():
            url = self.frontier.get_next_url()
            logger.info("Fetching URL %s ... Fetched: %s, Queue size: %s", url, self.frontier.fetched,
                        len(self.frontier))
            url_data = self.corpus.fetch_url(url)

            #add subdomain to dict here
            #creates a new dictionary entry of subdomain key, with value being the first baseurl passed
            self.subdomain[urlparse(url).netloc.lower()] = self.subdomain.get(urlparse(url).netloc.lower(), 0) + 1

            currentLinksNum  = 0

            for next_link in self.extract_next_links(url_data):
                if self.is_valid(next_link):

                    downloaded.add(url_data['url']) #add to set of downloaded urls if valid
                    """
                    prompt 1 -
                    we are looking at one url
                    create new entry if not
                    and add url to subdomain key set
                    """
                    url = url_data['url']

                    currentLinksNum += 1

                    #if the current counter is larger than the max counter, update maximum count and url (prompt 2)
                    if currentLinksNum > maxLinksNum:
                        maxLinksNum = currentLinksNum
                        maxLinksURL = url

                    content = self.change_html_to_text(url_data)
                    tokens = []
                    for sentence in content:
                        tokens += "".join((char if char.isalnum() else " ") for char in sentence).split()
                    tokens = [token.lower() for token in tokens if len(token) > 3 and (token not in stopwords)]
                    current_words = Counter(tokens)
                    if longesturl:
                        if len(tokens) > next(iter(longesturl.values())):
                            longesturl.clear()
                            longesturl[url] = len(tokens)
                    else:
                        longesturl[url] = len(tokens)
                    words += current_words

                    if self.corpus.get_file_name(next_link) is not None:
                        self.frontier.add_url(next_link)
        #
        #             #look at list of words from eachURL, add to new dictionary and update freq
        #
        #             for word in wordList:
        #                 if not word in stopwords:
        #                     if word in wordFreqDict:
        #                         wordFreqDict[word] +=1
        #                     if not word in wordFreqDict:
        #                         wordFreqDict[word] = 1
        #
        # sortedWordFreq = dict(sorted(wordFreqDict.items(), key=operator.itemgetter(1),reverse=True))
        #

        #set counter, if counter is larger than maxsoFar, update link and max (prompt 4)
        # currentNum = 0
        # for entry in wordsFound:
        #     currentNum = len(wordsFound[entry])
        #     if currentNum > maxWordsNum:
        #         maxWordsNum = currentNum
        #         maxWordsUrl = entry

        lytics1 = open("1_visited_subdomains.txt", "w", encoding='utf-8')
        print(self.subdomain, file=lytics1)
        lytics1.close()

        lytics2 = open("2_most_valid_out_links.txt", "w", encoding='utf-8')
        print('The page with the most valid out links is: ', maxLinksURL, 'The count is: ', maxLinksNum, file=lytics2)
        lytics2.close()

        lytics3 = open("3_downloaded_traps.txt", "w", encoding='utf-8')
        print('Number of traps found:', len(self.traps), '\nNumber of downloadedlinks found:', len(downloaded),
              '\ntraps: ', self.traps, '\ndownloadedurls:', downloaded, file=lytics3)
        lytics3.close()

        lytics4 = open("4_longest_page.txt", "w", encoding='utf-8')
        print('The page with the most words is: ', longesturl.keys(), ' with this many words: ', longesturl.values(), file=lytics4)
        lytics4.close()

        lytics5 = open("5_50_most_common_words.txt", "w", encoding='utf-8')
        print('The 50 most common words are:\n', words.most_common(50),file=lytics5)
        lytics5.close()

        # print('max subdomain is', max(count_dic, key=count_dic.get))

    def extract_next_links(self, url_data):
        """
        The url_data coming from the fetch_url method will be given as a parameter to this method. url_data contains the
        fetched url, the url content in binary format, and the size of the content in bytes. This method should return a
        list of urls in their absolute form (some links in the content are relative and needs to be converted to the
        absolute form). Validation of links is done later via is_valid method. It is not required to remove duplicates
        that have already been fetched. The frontier takes care of that.
        Suggested library: lxml
        """
        outputLinks = []
        print(url_data['is_redirected'])
        print(url_data['final_url'])
        print(url_data['http_code'])
        soup = BeautifulSoup(url_data['content'], "lxml")
        baseURL = url_data['url']
        if baseURL[0] != "h":
            baseURL = "https://" + baseURL
        parsed_url = urlparse(baseURL)
        if len(baseURL) < 200:
            if not url_data['is_redirected']:
                for link in soup.findAll('a'):
                    url = link.get('href')
                    if url is not None:
                        url = urljoin(baseURL, url)
                        url = urldefrag(url)[0]
                        outputLinks.append(url)
            else:
                parsed_final_url = urlparse(url_data['final_url'])
                if parsed_url.netloc == parsed_final_url.netloc:
                    for link in soup.findAll('a'):
                        url = link.get('href')
                        if url is not None:
                            url = urljoin(baseURL, url)
                            url = urldefrag(url)[0]
                            outputLinks.append(url)
                else:
                    if url_data['url'][-1] != "/":
                        url_data['url'] += "/"
                    url = url_data['final_url']
                    url = urldefrag(url)[0]
                    outputLinks.append(url)
        return outputLinks

    def is_valid(self, url):
        """
        Function returns True or False based on whether the url has to be fetched or not. This is a great place to
        filter out crawler traps. Duplicated urls will be taken care of by frontier. You don't need to check for duplication
        in this method
        """
        parsed = urlparse(url)
        if parsed.scheme not in set(["http", "https"]):
            return False
        # TODO
        if parsed.query.__contains__('login') or parsed.query.__contains__('action=') or parsed.query.__contains__('format='):
            return False
        if parsed.path.__contains__('login'):
            return False
        if "uci.edu" not in parsed.hostname:
            return False
        if len(url) > 200:
            self.traps.add(url)
            return False

        if parsed.query:
            if any(query in ['day', 'month', 'year', 'date'] for query in parse_qs(parsed.query).keys()):
                self.traps.add(url)
                return False
        
        if parsed.query:
            path = parsed.hostname + parsed.path
            self.valid_path[path] = self.valid_path.get(path, 0) + 1
            if self.valid_path[path] > 100:
                self.traps.add(url)
                return False

        folders = parsed.path.lower().split("/")
        if len(folders) - len(set(folders)) > 1:
            self.traps.add(url)
            return False

        # today = r"^today\.uci\.edu$"
        # calender = r"^\/department\/information_computer_sciences\/calendar(\/|\?)?((.)+)?$"
        # if re.match(today, parsed.netloc.lower()):
        #     if re.match(calender, parsed.path.lower()):
        #         return False
        # mailto = r"^mailto:.*"
        # if re.match(mailto, parsed.netloc.lower()):
        #     return False
        # wics = r".*wics\.ics\.uci\.edu/.*\?.*$"
        # if re.match(wics, url):
        #     return False
        # prospective = r"ics.uci.edu/prospective/.*$"
        # if re.match(prospective, parsed.netloc.lower()):
        #     return False
        # evoke = r".*evoke\.ics\.uci\.edu/.*replytocom=\d{5}$"
        # if re.match(evoke, url):
        #     return False
        # cbcl = r".*cbcl\.ics\.uci\.edu/public_data/.*"
        # if re.match(cbcl, url):
        #     return False
        # graph = r".*ganglia\.ics\.uci\.edu/graph\.php/.*"
        # if re.match(graph, url):
        #     return False
        # flamingo = r".*flamingo\.ics\.uci\.edu/releases/.*"
        # if re.match(flamingo, url):
        #     return False
        # if parsed.path.__contains__('pix'):
        #     return False
        # archive_pat = "archive.ics.uci.edu"
        # if re.match(archive_pat, parsed.netloc.lower()):
        #     return False
        if re.match(".*ics\.uci\.edu/.*\.(css|js|bmp|gif|jpe?g|ico" + "|png|tiff?|mid|mp2|mp3|mp4" \
                                    + "|wav|avi|mov|mpeg|ram|m4v|mkv|ogg|ogv|pdf" \
                                    + "|ps|eps|tex|ppt|pptx|doc|docx|xls|xlsx|names|data|dat|exe|bz2|tar|msi|bin|7z|psd|dmg|iso|epub|dll|cnf|tgz|sha1" \
                                    + "|thmx|mso|arff|rtf|jar|csv" \
                                    + "|rm|smil|wmv|swf|wma|zip|rar|gz|pdf|odp)$", url):
            return False

        try:
            return ".ics.uci.edu" in parsed.hostname \
                   and not re.match(".*\.(css|js|bmp|gif|jpe?g|ico" + "|png|tiff?|mid|mp2|mp3|mp4" \
                                    + "|wav|avi|mov|mpeg|ram|m4v|mkv|ogg|ogv|pdf" \
                                    + "|ps|eps|tex|ppt|pptx|doc|docx|xls|xlsx|names|data|dat|exe|bz2|tar|msi|bin|7z|psd|dmg|iso|epub|dll|cnf|tgz|sha1" \
                                    + "|thmx|mso|arff|rtf|jar|csv" \
                                    + "|rm|smil|wmv|swf|wma|zip|rar|gz|pdf|odp)$", parsed.path.lower())

        except TypeError:
            print("TypeError for ", parsed)
            return False